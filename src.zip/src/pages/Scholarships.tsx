import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { collection, deleteDoc, doc, getDocs, orderBy, query, setDoc } from "firebase/firestore";
import { db } from "../lib/firebase";
import { useAuth } from "../lib/auth";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Input } from "../components/ui/input";
import { Search, MapPin, Calendar, BookOpen, ExternalLink, SlidersHorizontal, Loader2, Bookmark, BookmarkCheck, X, Filter, Check, GraduationCap, ArrowUpDown } from "lucide-react";
import { Scholarship } from "../types";
import { toast } from "sonner";
import Markdown from "react-markdown";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger, SheetClose, SheetFooter } from "../components/ui/sheet";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "../components/ui/dialog";
import { ScrollArea } from "../components/ui/scroll-area";

const STANDARD_FIELDS = ["Teknik", "Sains & Teknologi", "Bisnis & Manajemen", "Hukum", "Seni & Desain", "Pendidikan", "Kesehatan & Kedokteran", "Humaniora & Sosial", "Pertanian & Lingkungan", "Agama & Filsafat", "Umum / Lintas Bidang"];

const DEFAULT_COUNTRIES = ["Indonesia", "Amerika Serikat", "Inggris", "Australia", "Kanada", "Jerman", "Belanda", "Jepang", "Korea Selatan", "Singapura", "Malaysia", "Prancis", "Swiss"];

const normalizeField = (field?: string) => {
  const value = field?.trim().toLowerCase();

  if (!value) return "Umum / Lintas Bidang";
  if (/(semua bidang|lintas bidang|berbagai bidang|multidisiplin)/.test(value)) return "Umum / Lintas Bidang";
  if (/(teknik|engineering|rekayasa|sipil|mesin|elektro|industri|arsitektur|informatika|komputer|data|robot|mekatronika)/.test(value)) return "Teknik";
  if (/(sains|science|fisika|kimia|biologi|matematika|statistika|teknologi)/.test(value)) return "Sains & Teknologi";
  if (/(bisnis|manajemen|ekonomi|akuntansi|keuangan|marketing|wirausaha|entrepreneur|commerce)/.test(value)) return "Bisnis & Manajemen";
  if (/(hukum|law|legal|peradilan)/.test(value)) return "Hukum";
  if (/(seni|desain|art|musik|film|kriya|visual|creative)/.test(value)) return "Seni & Desain";
  if (/(pendidikan|education|guru|mengajar|pedagogi|kependidikan)/.test(value)) return "Pendidikan";
  if (/(kesehatan|kedokteran|medicine|farmasi|keperawatan|nursing|gizi|kebidanan|medis|public health)/.test(value)) return "Kesehatan & Kedokteran";
  if (/(humaniora|sosial|sosiologi|psikologi|komunikasi|politik|sejarah|filsafat|bahasa|antropologi|hubungan internasional)/.test(value)) return "Humaniora & Sosial";
  if (/(pertanian|agrikultur|lingkungan|kelautan|perikanan|kehutanan)/.test(value)) return "Pertanian & Lingkungan";
  if (/(agama|teologi)/.test(value)) return "Agama & Filsafat";

  return "Umum / Lintas Bidang";
};

export default function Scholarships() {
  const navigate = useNavigate();
  const { user, isPremium } = useAuth();
  const [scholarships, setScholarships] = useState<Scholarship[]>([]);
  const [bookmarks, setBookmarks] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filtered, setFiltered] = useState<Scholarship[]>([]);
  const [selectedFields, setSelectedFields] = useState<string[]>([]);
  const [selectedCountries, setSelectedCountries] = useState<string[]>([]);
  const [fieldSearchQuery, setFieldSearchQuery] = useState("");
  const [countrySearchQuery, setCountrySearchQuery] = useState("");
  const [showAllFilterChips, setShowAllFilterChips] = useState(false);
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc");
  const [failedImageMap, setFailedImageMap] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const fetchData = async () => {
      try {
        const q = query(collection(db, "scholarships"), orderBy("deadline", "asc"));
        const snapshot = await getDocs(q);
        const data = snapshot.docs.map((snapshotDoc) => ({ id: snapshotDoc.id, ...snapshotDoc.data() })) as Scholarship[];
        setScholarships(data);
        setFiltered(data);

        if (user) {
          const bookmarkSnapshot = await getDocs(collection(db, "users", user.uid, "bookmarks"));
          setBookmarks(bookmarkSnapshot.docs.map((snapshotDoc) => snapshotDoc.id));
        }
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [user]);

  useEffect(() => {
    let result = scholarships;

    if (search.trim()) {
      const low = search.toLowerCase();
      result = result.filter(
        (scholarship) =>
          scholarship.title.toLowerCase().includes(low) ||
          scholarship.description.toLowerCase().includes(low) ||
          scholarship.field?.toLowerCase().includes(low) ||
          scholarship.country?.toLowerCase().includes(low) ||
          scholarship.eligibility?.toLowerCase().includes(low),
      );
    }

    if (selectedFields.length > 0) {
      result = result.filter((scholarship) => selectedFields.includes(normalizeField(scholarship.field)));
    }

    if (selectedCountries.length > 0) {
      result = result.filter((scholarship) => selectedCountries.includes(scholarship.country || ""));
    }

    if (startDate) {
      result = result.filter((scholarship) => new Date(scholarship.deadline) >= new Date(startDate));
    }

    if (endDate) {
      result = result.filter((scholarship) => new Date(scholarship.deadline) <= new Date(endDate));
    }

    const sortedResult = [...result].sort((a, b) => {
      const dateA = new Date(a.deadline).getTime();
      const dateB = new Date(b.deadline).getTime();
      return sortOrder === "asc" ? dateA - dateB : dateB - dateA;
    });

    setFiltered(sortedResult);
  }, [search, selectedFields, selectedCountries, scholarships, startDate, endDate, sortOrder]);

  const countries = Array.from(new Set([...DEFAULT_COUNTRIES, ...scholarships.map((scholarship) => scholarship.country).filter(Boolean)])).sort((a, b) => a.localeCompare(b));
  const filteredFieldOptions = STANDARD_FIELDS.filter((field) => field.toLowerCase().includes(fieldSearchQuery.trim().toLowerCase()));
  const filteredCountryOptions = countries.filter((country) => country.toLowerCase().includes(countrySearchQuery.trim().toLowerCase()));

  const toggleBookmark = async (scholarship: Scholarship) => {
    if (!user) {
      toast.error("Silakan login untuk menyimpan beasiswa");
      return;
    }

    const isBookmarked = bookmarks.includes(scholarship.id!);
    const docRef = doc(db, "users", user.uid, "bookmarks", scholarship.id!);

    try {
      if (isBookmarked) {
        await deleteDoc(docRef);
        setBookmarks((prev) => prev.filter((id) => id !== scholarship.id));
        toast.info("Berhasil dihapus dari simpanan");
      } else {
        if (!isPremium && bookmarks.length >= 3) {
          toast.error("Batas bookmark gratis (3) tercapai. Upgrade ke Premium untuk akses Unlimited!");
          return;
        }

        await setDoc(docRef, {
          scholarshipId: scholarship.id,
          title: scholarship.title,
          deadline: scholarship.deadline,
          createdAt: new Date().toISOString(),
        });
        setBookmarks((prev) => [...prev, scholarship.id!]);
        toast.success("Berhasil disimpan!");
      }
    } catch (error) {
      toast.error("Gagal memperbarui bookmark");
    }
  };

  const clearFilters = () => {
    setSearch("");
    setSelectedFields([]);
    setSelectedCountries([]);
    setFieldSearchQuery("");
    setCountrySearchQuery("");
    setStartDate("");
    setEndDate("");
    setSortOrder("desc");
    setShowAllFilterChips(false);
  };

  const toggleFieldSelection = (field: string) => {
    setSelectedFields((prev) => (prev.includes(field) ? prev.filter((item) => item !== field) : [...prev, field]));
  };

  const toggleCountrySelection = (country: string) => {
    setSelectedCountries((prev) => (prev.includes(country) ? prev.filter((item) => item !== country) : [...prev, country]));
  };

  const activeFilterItems = [
    ...selectedFields.map((field) => ({ type: "field" as const, value: field })),
    ...selectedCountries.map((country) => ({ type: "country" as const, value: country })),
    ...(startDate || endDate ? [{ type: "date" as const, value: `${startDate ? startDate : ""} - ${endDate ? endDate : ""}` }] : []),
    ...(sortOrder === "desc" ? [{ type: "sort" as const, value: "Terjauh" }] : [{ type: "sort" as const, value: "Terdekat" }]),
  ];

  const compactPreviewItems = activeFilterItems.slice(0, 2);
  const hiddenFilterCount = Math.max(activeFilterItems.length - compactPreviewItems.length, 0);
  const visibleScholarships = user ? filtered : filtered.slice(0, 3);

  const handleOpenDetailForGuest = () => {
    toast.error("Detail beasiswa tersedia setelah login.");
    navigate("/auth", { state: { from: { pathname: "/scholarships" } } });
  };

  return (
    <div className="sp-page-container">
      <div className="sp-page-header flex flex-col gap-8 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="sp-page-title">Jelajahi Beasiswa</h1>
          <p className="sp-page-subtitle max-w-lg leading-relaxed">Temukan ribuan peluang pendidikan dari berbagai institusi terbaik di Indonesia.</p>
        </div>

        <div className="flex w-full max-w-xl items-center gap-3">
          <div className="relative flex-grow group">
            <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" />
            <Input
              placeholder="Cari kata kunci, universitas..."
              className="pl-12 h-12 rounded-2xl border-slate-200 bg-white shadow-sm focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all font-medium"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          <Sheet>
            <SheetTrigger
              render={
                <Button
                  variant="outline"
                  className={`h-12 px-5 rounded-2xl border-slate-200 bg-white shadow-sm shrink-0 font-bold flex items-center gap-2 hover:border-indigo-200 hover:bg-white transition-all relative ${activeFilterItems.length > 0 ? "border-indigo-400 ring-2 ring-indigo-500/10 bg-indigo-50/10" : ""}`}
                >
                  <SlidersHorizontal className={`h-4 w-4 ${activeFilterItems.length > 0 ? "text-indigo-600" : "text-slate-600"}`} />
                  <span className={activeFilterItems.length > 0 ? "text-indigo-700" : "text-slate-700"}>Filter</span>
                  {activeFilterItems.length > 0 && (
                    <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-indigo-600 text-[10px] font-bold text-white ring-2 ring-white">{activeFilterItems.length}</span>
                  )}
                </Button>
              }
            />
            <SheetContent className="border-l border-slate-100 flex flex-col p-0 sm:right-6 sm:top-6 sm:bottom-6 sm:h-auto sm:w-[min(28rem,calc(100vw-3rem))] sm:max-w-[28rem] sm:rounded-3xl sm:shadow-2xl">
              <SheetHeader className="p-6 pb-6 border-b border-slate-100">
                <SheetTitle className="text-xl font-black tracking-tight flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center text-indigo-600">
                    <Filter className="h-5 w-5" />
                  </div>
                  Filter Hasil
                </SheetTitle>
                <SheetDescription className="text-slate-500 font-medium pt-1">Pilih lebih dari satu bidang dan negara agar hasil lebih relevan.</SheetDescription>
              </SheetHeader>

              <div className="flex-grow overflow-y-auto p-6 space-y-8 py-6">
                <div className="space-y-4">
                  <div className="flex items-center gap-2 mb-2">
                    <BookOpen size={14} className="text-indigo-500" />
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Kategori Bidang</label>
                  </div>
                  <Input value={fieldSearchQuery} onChange={(e) => setFieldSearchQuery(e.target.value)} placeholder="Cari bidang..." className="h-11 rounded-xl border-slate-100 bg-white" />
                  <div className="rounded-2xl border border-slate-100 bg-slate-50/70 p-2 max-h-52 overflow-auto space-y-1.5">
                    {filteredFieldOptions.length > 0 ? (
                      filteredFieldOptions.map((field) => {
                        const active = selectedFields.includes(field);
                        return (
                          <button
                            key={field}
                            type="button"
                            onClick={() => toggleFieldSelection(field)}
                            className={`w-full rounded-xl px-3 py-2.5 text-left text-sm font-semibold transition-colors min-h-11 flex items-start justify-between gap-3 ${active ? "bg-indigo-600 text-white" : "bg-white text-slate-700 hover:bg-indigo-50 hover:text-indigo-700"}`}
                          >
                            <span className="leading-snug break-words">{field}</span>
                            <span className={`mt-0.5 inline-flex h-4 w-4 shrink-0 items-center justify-center rounded-full border ${active ? "border-white/80 bg-white/15" : "border-slate-300 bg-white"}`}>
                              {active && <Check size={12} />}
                            </span>
                          </button>
                        );
                      })
                    ) : (
                      <p className="px-2 py-1 text-xs font-medium text-slate-400">Tidak ada bidang yang cocok.</p>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-400 font-medium">Bisa pilih lebih dari satu bidang.</p>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center gap-2 mb-2">
                    <MapPin size={14} className="text-indigo-500" />
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Wilayah / Negara</label>
                  </div>
                  <Input value={countrySearchQuery} onChange={(e) => setCountrySearchQuery(e.target.value)} placeholder="Cari negara..." className="h-11 rounded-xl border-slate-100 bg-white" />
                  <div className="rounded-2xl border border-slate-100 bg-slate-50/70 p-2 max-h-52 overflow-auto space-y-1.5">
                    {filteredCountryOptions.length > 0 ? (
                      filteredCountryOptions.map((country) => {
                        const active = selectedCountries.includes(country);
                        return (
                          <button
                            key={country}
                            type="button"
                            onClick={() => toggleCountrySelection(country)}
                            className={`w-full rounded-xl px-3 py-2.5 text-left text-sm font-semibold transition-colors min-h-11 flex items-start justify-between gap-3 ${active ? "bg-indigo-600 text-white" : "bg-white text-slate-700 hover:bg-indigo-50 hover:text-indigo-700"}`}
                          >
                            <span className="leading-snug break-words">{country}</span>
                            <span className={`mt-0.5 inline-flex h-4 w-4 shrink-0 items-center justify-center rounded-full border ${active ? "border-white/80 bg-white/15" : "border-slate-300 bg-white"}`}>
                              {active && <Check size={12} />}
                            </span>
                          </button>
                        );
                      })
                    ) : (
                      <p className="px-2 py-1 text-xs font-medium text-slate-400">Tidak ada negara yang cocok.</p>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-400 font-medium">Bisa pilih lebih dari satu negara.</p>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Calendar size={14} className="text-indigo-500" />
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Batas Akhir / Deadline</label>
                  </div>
                  <div className="flex gap-3">
                    <div className="flex-1 space-y-1">
                      <label className="text-[10px] font-semibold text-slate-500">Mulai dari</label>
                      <Input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} className="h-11 rounded-xl border-slate-100 bg-white text-sm" />
                    </div>
                    <div className="flex-1 space-y-1">
                      <label className="text-[10px] font-semibold text-slate-500">Sampai dengan</label>
                      <Input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} className="h-11 rounded-xl border-slate-100 bg-white text-sm" />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center gap-2 mb-2">
                    <ArrowUpDown size={14} className="text-indigo-500" />
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Urutkan Berdasarkan</label>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setSortOrder("asc")}
                      className={`h-11 rounded-xl text-sm font-semibold transition-all ${sortOrder === "asc" ? "border-indigo-600 bg-indigo-50 text-indigo-700" : "border-slate-200 text-slate-600"}`}
                    >
                      Terdekat
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setSortOrder("desc")}
                      className={`h-11 rounded-xl text-sm font-semibold transition-all ${sortOrder === "desc" ? "border-indigo-600 bg-indigo-50 text-indigo-700" : "border-slate-200 text-slate-600"}`}
                    >
                      Terjauh
                    </Button>
                  </div>
                </div>
              </div>

              <SheetFooter className="p-6 border-t border-slate-100 flex-row gap-3 bg-slate-50/50">
                <Button variant="ghost" onClick={clearFilters} className="flex-1 rounded-2xl font-bold text-slate-400 hover:text-red-500 hover:bg-red-50 transition-all h-12">
                  Reset
                </Button>
                <SheetClose render={<Button className="flex-1 bg-slate-900 text-white rounded-2xl font-bold h-12 shadow-lg shadow-slate-200">Selesai</Button>} />
              </SheetFooter>
            </SheetContent>
          </Sheet>
        </div>
      </div>

      {(activeFilterItems.length > 0 || search) && (
        <div className="mb-8 rounded-2xl border border-slate-100 bg-white px-4 py-3 shadow-sm animate-in fade-in slide-in-from-top-4 duration-500">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:gap-4">
            <div className="flex items-center gap-2 shrink-0">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.24em]">Penyaringan</span>
              <Badge variant="secondary" className="bg-slate-900 text-white border-none px-2.5 py-1 text-[10px] font-bold">
                {activeFilterItems.length + (search ? 1 : 0)} aktif
              </Badge>
            </div>

            <div className="flex-1 overflow-x-auto pb-1">
              <div className="flex min-w-max items-center gap-2 flex-nowrap">
                {search && (
                  <Badge variant="secondary" className="pl-3 pr-1 py-1 rounded-full bg-slate-900 text-white flex items-center gap-2 border-none shadow-sm text-[10px] font-bold">
                    <span>"{search}"</span>
                    <button onClick={() => setSearch("")} className="p-1 rounded-full hover:bg-white/20 transition-colors text-white/60 hover:text-white">
                      <X size={11} strokeWidth={3} />
                    </button>
                  </Badge>
                )}

                {(showAllFilterChips ? activeFilterItems : compactPreviewItems).map((item) => (
                  <Badge key={`${item.type}-${item.value}`} variant="secondary" className="pl-3 pr-1 py-1 rounded-full bg-indigo-50 text-indigo-700 border-indigo-100/70 flex items-center gap-2 shadow-sm text-[10px] font-bold">
                    {item.type === "field" ? <BookOpen size={11} className="text-indigo-400" /> : item.type === "country" ? <MapPin size={11} className="text-indigo-400" /> : item.type === "sort" ? <ArrowUpDown size={11} className="text-indigo-400" /> : <Calendar size={11} className="text-indigo-400" />}
                    <span className="uppercase tracking-tight whitespace-nowrap">{item.value}</span>
                    <button
                      onClick={() => {
                        if (item.type === "field") toggleFieldSelection(item.value);
                        else if (item.type === "country") toggleCountrySelection(item.value);
                        else if (item.type === "sort") setSortOrder("desc");
                        else {
                          setStartDate("");
                          setEndDate("");
                        }
                      }}
                      className="p-1 rounded-full hover:bg-indigo-100 transition-colors text-indigo-400 hover:text-indigo-700"
                    >
                      <X size={11} strokeWidth={3} />
                    </button>
                  </Badge>
                ))}

                {!showAllFilterChips && hiddenFilterCount > 0 && (
                  <Badge variant="outline" className="px-2.5 py-1 text-[10px] font-bold border-slate-200 text-slate-500 bg-slate-50 whitespace-nowrap">
                    +{hiddenFilterCount} lainnya
                  </Badge>
                )}
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0 lg:ml-auto">
              {activeFilterItems.length > 2 && (
                <Button variant="ghost" size="sm" onClick={() => setShowAllFilterChips((prev) => !prev)} className="h-8 px-3 rounded-full text-[10px] font-bold text-slate-500 hover:text-slate-900 hover:bg-slate-100">
                  {showAllFilterChips ? "Ringkas" : "Lihat semua"}
                </Button>
              )}

              <Button variant="ghost" size="sm" onClick={clearFilters} className="text-[10px] font-bold text-red-500 hover:text-red-600 hover:bg-red-50 uppercase tracking-widest h-8 px-3 rounded-full">
                Bersihkan
              </Button>
            </div>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex h-96 flex-col items-center justify-center gap-4">
          <Loader2 className="h-10 w-10 animate-spin text-indigo-600" />
          <p className="text-slate-400 font-medium">Menyiapkan inspirasi masa depan...</p>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {visibleScholarships.map((scholarship, idx) => {
              const imageKey = scholarship.id || scholarship.title;
              const isBrokenImage = failedImageMap[imageKey];
              const fieldLabel = normalizeField(scholarship.field);

              return (
                <Card key={scholarship.id} className="group flex flex-col overflow-hidden border-slate-100 shadow-sm rounded-3xl transition-all hover:border-indigo-200 hover:shadow-2xl hover:shadow-indigo-500/10 bg-white">
                  <div className="relative aspect-[16/10] w-full overflow-hidden bg-slate-100">
                    {(!scholarship.imageUrl || isBrokenImage) && (
                      <>
                        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(15,23,42,0.08),transparent_40%),radial-gradient(circle_at_80%_70%,rgba(15,23,42,0.06),transparent_45%)]" />
                        <div className="absolute inset-0 flex items-center justify-center text-slate-700/80">
                          <GraduationCap size={idx % 2 === 0 ? 96 : 78} strokeWidth={1.2} />
                        </div>
                      </>
                    )}

                    {scholarship.imageUrl && !isBrokenImage && (
                      <img
                        src={scholarship.imageUrl}
                        alt={scholarship.title}
                        className="absolute inset-0 h-full w-full object-cover"
                        referrerPolicy="no-referrer"
                        onError={() => setFailedImageMap((prev) => ({ ...prev, [imageKey]: true }))}
                      />
                    )}

                    <div className="absolute top-4 right-4 flex gap-2">
                      <Badge className="bg-white/95 backdrop-blur text-indigo-700 shadow-sm border-none font-bold px-3">{scholarship.country || "Indonesia"}</Badge>
                      <Button
                        variant="secondary"
                        size="icon"
                        className={`h-9 w-9 rounded-full shadow-lg backdrop-blur border-none transition-all ${bookmarks.includes(scholarship.id!) ? "bg-indigo-600 text-white hover:bg-indigo-700 scale-110" : "bg-white/80 text-slate-400 hover:text-indigo-600 hover:bg-white"}`}
                        onClick={() => toggleBookmark(scholarship)}
                      >
                        {bookmarks.includes(scholarship.id!) ? <BookmarkCheck size={18} /> : <Bookmark size={18} />}
                      </Button>
                    </div>
                  </div>

                  <CardHeader className="p-6 pb-0">
                    <div className="flex items-center gap-2 text-[10px] font-bold text-indigo-600 uppercase tracking-widest mb-3 px-3 py-1 bg-indigo-50/50 w-fit rounded-full border border-indigo-100/50">
                      <BookOpen size={12} />
                      <span>{fieldLabel}</span>
                    </div>
                    <CardTitle className="text-xl font-black line-clamp-2 leading-tight group-hover:text-indigo-600 transition-colors">{scholarship.title}</CardTitle>
                    <CardDescription className="line-clamp-2 mt-3 text-slate-500 font-medium leading-relaxed">{scholarship.description}</CardDescription>
                  </CardHeader>

                  <CardContent className="flex-grow p-6 pt-4">
                    <div className="flex items-center gap-3 text-slate-600">
                      <div className="flex items-center justify-center w-8 h-8 rounded-full bg-slate-50 text-slate-400">
                        <Calendar size={14} />
                      </div>
                      <div>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter">Batas Akhir</p>
                        <p className="text-xs font-bold text-slate-900">{scholarship.deadline}</p>
                      </div>
                    </div>
                  </CardContent>

                  <CardFooter className="pt-0 p-6">
                    {user ? (
                      <Dialog>
                        <DialogTrigger render={<Button className="w-full h-12 bg-slate-900 text-white hover:bg-indigo-600 rounded-2xl font-bold shadow-lg shadow-slate-200">Detail Beasiswa</Button>} />
                        <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden flex flex-col p-0 rounded-3xl">
                          <div className="p-8 bg-indigo-600 text-white">
                            <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.2em] mb-4 text-indigo-100 opacity-80">
                              <MapPin size={14} /> {scholarship.country || "Indonesia"} • {fieldLabel}
                            </div>
                            <DialogTitle className="text-3xl font-black leading-tight mb-2 pr-8">{scholarship.title}</DialogTitle>
                            <div className="flex items-center gap-2 mt-4">
                              <Badge variant="secondary" className="bg-white/20 text-white border-none font-bold">
                                Deadline: {scholarship.deadline}
                              </Badge>
                            </div>
                          </div>

                          <ScrollArea className="flex-grow">
                            <div className="p-8 space-y-10">
                              <section>
                                <h3 className="text-sm font-black text-slate-400 uppercase tracking-widest mb-4">Tentang Beasiswa</h3>
                                <p className="text-slate-600 leading-relaxed font-medium">{scholarship.description}</p>
                              </section>

                              <section className="p-6 rounded-2xl bg-indigo-50/50 border border-indigo-100/50">
                                <h3 className="text-sm font-black text-indigo-900 uppercase tracking-widest mb-4">Kriteria Kelayakan</h3>
                                <div className="text-indigo-800 leading-relaxed font-medium text-sm prose prose-sm prose-indigo max-w-none prose-p:my-2 prose-li:my-1 prose-ul:list-disc prose-ol:list-decimal prose-li:marker:text-indigo-400">
                                  <Markdown>{scholarship.eligibility}</Markdown>
                                </div>
                              </section>

                              {scholarship.benefits && (
                                <section>
                                  <h3 className="text-sm font-black text-slate-400 uppercase tracking-widest mb-4">Benefit & Besaran</h3>
                                  <div className="text-slate-600 leading-relaxed font-medium text-sm prose prose-sm max-w-none prose-p:my-2 prose-li:my-1 prose-ul:list-disc prose-ol:list-decimal prose-li:marker:text-indigo-300">
                                    <Markdown>{scholarship.benefits}</Markdown>
                                  </div>
                                </section>
                              )}

                              {scholarship.selectionProcess && (
                                <section>
                                  <h3 className="text-sm font-black text-slate-400 uppercase tracking-widest mb-4">Proses Seleksi</h3>
                                  <div className="text-slate-600 leading-relaxed font-medium text-sm prose prose-sm max-w-none prose-p:my-2 prose-li:my-1 prose-ul:list-disc prose-ol:list-decimal prose-li:marker:text-indigo-300">
                                    <Markdown>{scholarship.selectionProcess}</Markdown>
                                  </div>
                                </section>
                              )}
                            </div>
                          </ScrollArea>

                          <div className="p-8 pt-4 border-t border-slate-100 flex items-center gap-4">
                            {scholarship.link ? (
                              <Button asChild className="flex-grow h-14 bg-indigo-600 text-white hover:bg-slate-900 rounded-2xl font-black shadow-xl shadow-indigo-100">
                                <a href={scholarship.link} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center gap-2">
                                  DAFTAR SEKARANG <ExternalLink size={18} />
                                </a>
                              </Button>
                            ) : (
                              <Button disabled className="flex-grow h-14 rounded-2xl font-black">
                                LINK PENDAFTARAN BELUM TERSEDIA
                              </Button>
                            )}

                            <Button
                              variant="outline"
                              size="icon"
                              className={`h-14 w-14 rounded-2xl border-2 transition-all ${bookmarks.includes(scholarship.id!) ? "bg-indigo-50 border-indigo-200 text-indigo-600" : "border-slate-100 text-slate-300"}`}
                              onClick={() => toggleBookmark(scholarship)}
                            >
                              <Bookmark size={20} fill={bookmarks.includes(scholarship.id!) ? "currentColor" : "none"} />
                            </Button>
                          </div>
                        </DialogContent>
                      </Dialog>
                    ) : (
                      <Button onClick={handleOpenDetailForGuest} className="w-full h-12 bg-slate-900 text-white hover:bg-indigo-600 rounded-2xl font-bold shadow-lg shadow-slate-200">
                        Login untuk Detail
                      </Button>
                    )}
                  </CardFooter>
                </Card>
              );
            })}
          </div>

          {!loading && filtered.length === 0 && (
            <div className="mt-8 flex flex-col items-center justify-center py-24 text-center bg-white rounded-[40px] border-2 border-dashed border-slate-100">
              <div className="rounded-full bg-slate-50 p-10 mb-6 shadow-inner">
                <Search className="h-12 w-12 text-slate-200" />
              </div>
              <h3 className="text-2xl font-black text-slate-900 uppercase">Pencarian Nihil</h3>
              <p className="mt-3 text-slate-500 max-w-sm mx-auto font-medium leading-relaxed">Kami tidak menemukan beasiswa yang cocok. Coba atur ulang filter atau gunakan kata kunci lain.</p>
              <Button variant="outline" onClick={clearFilters} className="mt-8 rounded-xl px-8 h-12 font-bold">
                Atur Ulang Semua Filter
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
